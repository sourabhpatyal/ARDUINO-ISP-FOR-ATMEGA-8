# Arduino-As-ISP-Burn-Hex-File-in-AVR-Fuse-in-AVR-Arduino-As-Programmer
This article is all about arduino as isp.  If you want to upload hex file or if you want to set your fuse in AVR then you no need to buy a programmer, you can do it with arduino.  In this article i have uploaded hex file in atmega8 if you want to upload hex file in other AVR then understand the process and follow same steps.


here is link of video:https://www.youtube.com/watch?v=_nE8Tir_o_A&t=949s
